#######################################################################
# Author:        Anthony A. Stock, NASA GRC/LCI [SIP]
# Creation date: 26 February 2021
# Module Name:   SingleTermCFE_in.py
# Description:   asdf
#######################################################################

import numpy as np

from matplotlib        import pyplot as plt
from commpy.channels   import awgn
from commpy.filters    import rrcosfilter
from commpy.modulation import QAMModem
from commpy.utilities  import dec2bitarray
from scipy.signal      import welch, upfirdn
from scipy.fftpack     import fft, fftshift

###### GLOBAL CONSTANTS### ###########################################
Fs       = 1.00e6
fracBits = 15
Span     = 6

# generate a huge amount of messages, but only transmit a portion
NMessages = 2**14

# simulation tracking
simNum  = 8
#simStr  = "Real_World"
#dirName = "Experiment_" + str(simNum) + "--" + simStr

#####################################################################
def main():

    #
    # Simulate Transmitters
    #

    NWaveforms = 1;

    # Waveform Index ##        0     1 
    Rs         = np.array([0.10,  0.20])*1e6      #non-over: 0.10,0.25;    over: 0.10, 0.25
    fc         = np.array([0.05,  0.20])*1e6      #non-over: -0.2, 0.2:    over: 0.05, 0.10
    Rolloff    = np.array([0.20,   0.35])
    EbN0       = np.array([15.0,  15.00]) # dB
    ModulationOrder = np.array([4, 4])
    NIQSamples = 2**12

    validMag = 0
    while(validMag < 300):
        # create a buffer of maximum possible size
        x = np.zeros(NMessages)
        for i in range(NWaveforms):
            wf              = transmitter(ModulationOrder[i], Rs[i], fc[i], Rolloff[i], 1)
            ch              = channel(wf, ModulationOrder[i], Rs[i], EbN0[i]);        
            x               = x[:NIQSamples] + ch[:NIQSamples];

        
        #
        # Simulate ADC
        #

        # normalize again
        x = x / max(max(abs(x.real)),max(abs(x.imag)))

        #print("after second norm: ",max(x*np.conj(x)))
        '''
        f, Pxx = welch(x,Fs,return_onesided=False, noverlap=len(x)/4, nperseg=len(x)/2, nfft=len(x)/2, scaling='spectrum')
        plt.semilogy(f/1e6, Pxx*1e6)
        plt.xlabel("f (MHz)")
        plt.ylabel("Pxx(f)")
        plt.title('M-QAM-SRRC')
        plt.show()
        '''
    
        # debugging waveforms
        #x_t = np.arange(Nsamples)
        #x = np.exp((1j*2*pi*fc[0]/Fs*osc_t)# * np.exp(-1j*theta)
        #x = np.ones(NIQSamples) * np.sqrt(2)/2 + 1j * np.ones(NIQSamples) * np.sqrt(2)/2
        #x = np.ones(NIQSamples) + 1j * np.ones(NIQSamples)
    
        # simulate gain control by
        # normalizing I and Q components
        #x = x / max(x) # this one ends up being greater than 1.0 for some reason
        
        x = x * (2**(fracBits)-1)/(2**fracBits)
        #print("N: 2**" + str(int(np.log2(len(x)))))
        print("Max value I/Q: ", max(abs(x.real)), max(abs(x.imag)), "n = ", validMag)

        # detection threshold
        beta = 1e-4
        threshold = beta * (sum(abs(x)**2)/len(x))**2
        #print("Threshold:", str(threshold))
    
        # simulate quantization by
        # using fixed-point rounding
        x_Fx_Real = np.round(x.real*(2**fracBits)).astype(int)
        x_Fx_Imag = np.round(x.imag*(2**fracBits)).astype(int)

        # simulate sampling by
        # writing IQ samples to file

        if( max(abs(x.real)) > 0.95 and max(abs(x.imag)) > 0.95):

            with open("Exp"+str(simNum)+"/i_in"+str(validMag)+".txt", 'w') as realFile:
            #with open("baseline/i_in"+str(validMag)+".txt", 'w') as realFile:
                for i in range(len(x_Fx_Real)):
                    realFile.write(str(x_Fx_Real[i]) + "\n")

            with open("Exp"+str(simNum)+"/q_in"+str(validMag)+".txt", 'w') as imagFile:
            #with open("baseline/q_in"+str(validMag)+".txt", 'w') as imagFile:
                for i in range(len(x_Fx_Imag)):
                    imagFile.write(str(x_Fx_Imag[i]) + "\n")

            validMag += 1

    
    
#########################################################################            
def transmitter(ModulationOrder, Rs, fc, Rolloff, d):
    # generate modem
    Modulator = QAMModem(ModulationOrder)

    # generate messages
    RandomInts = np.random.randint(0,ModulationOrder,NMessages)

    # convert messages to bits
    RandomBits = dec2bitarray(RandomInts,Modulator.num_bits_symbol)

    # convert bits to symbols
    RandomSymbols = Modulator.modulate(RandomBits)
    
    # generate pulse shape filter
    SamplesPerSymbol = Fs/Rs
    NTapsRrc         = Span*SamplesPerSymbol + 1
    PsfIdxs, Psf     = rrc(int(NTapsRrc), Rolloff, 1/Rs, Fs)
    
    # normalize total energy of psf to 1
    Psf = Psf / np.sqrt(sum(Psf)) 
        
    # resample & pulse shape symbols to create baseband signal
    # output length = (Fs/Rs)*(Nmessages+Span)
    rat = SamplesPerSymbol.as_integer_ratio()
    x   = upfirdn(Psf, RandomSymbols, rat[0], rat[1])    
    
    # upconvert from baseband to passband
    # d -> positive: rhs of spectrum, negative: lhs of spectrum
    LocalOsc = np.exp(d*1j*2*np.pi*fc/Fs * np.arange(len(x)))
    x        = x * LocalOsc

    #print("before norm: ",max(x*np.conj(x)))
    
    # normalize to magnitude of 1
    normFactor = 1 / max(max(abs(x.real)),max(abs(x.imag)))
    x = x*normFactor
 
    return x

#########################################################################
def channel(x, ModulationOrder, Rs, EbN0):
    #EsN0 = EbN0 + 10*np.log10(np.log2(ModulationOrder))
    #CNR  = EsN0 - 10*np.log10(Fs/Rs)
    #y    = awgn(x, CNR)

    EsN0 = EbN0 + 10*np.log10(np.log2(ModulationOrder))
    CNR  = EsN0 - 10*np.log10(Fs/Rs)
    '''
    # calculate signal power in db
    x_pwr        = abs(x)**2
    x_pwr_avg    = np.mean(x_pwr)
    x_avg_db     = 10*np.log10(x_pwr_avg)

    # calculate noise based on desired CNR
    noise_avg_db  = x_avg_db - CNR
    noise_avg_pwr = 10**(noise_avg_db/10)
    noise = np.random.normal(0,np.sqrt(noise_avg_pwr),len(x))
    '''
    # add noise to signal
    #y = x + noise   # OR:
    y = awgn(x, CNR)
    
    #print("CNR:", CNR)
    #print("before noise: ",max(x*np.conj(x)))
    #print("after  noise: ",max(y*np.conj(y)))
    return y

def rrc(N, alpha, Ts, Fs):
    T_delta    = 1/float(Fs)
    time_idx   = ((np.arange(N)-N/2))*T_delta
    sample_num = np.arange(N)
    h_rrc      = np.zeros(N, dtype=float)

    for x in sample_num:
        t = (x-N/2)*T_delta
        t = round(t,30)
        if t == 0.0:
            h_rrc[x] = (1.0 - alpha + (4*alpha/np.pi))
        elif (alpha != 0 and t == Ts/(4*alpha)) or (alpha != 0 and t == -Ts/(4*alpha)):
            h_rrc[x] = (alpha/np.sqrt(2)) * (((1+2/np.pi)*(np.sin(np.pi/(4*alpha))))+((1-2/np.pi)*(np.cos(np.pi/(4*alpha)))))
        else:
            h_rrc[x] = (np.sin(np.pi*t*(1-alpha)/Ts) + 4*alpha*(t/Ts)*np.cos(np.pi*t*(1+alpha)/Ts)) / (np.pi*t*(1-(4*alpha*t/Ts)*(4*alpha*t/Ts))/Ts)
    return time_idx, h_rrc
    
##########################################################################
if __name__ == "__main__":
    main()

